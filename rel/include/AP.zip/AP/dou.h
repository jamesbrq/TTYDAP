#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyDouPatches(OSModuleInfo* module_info);

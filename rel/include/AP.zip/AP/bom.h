#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyBomPatches(OSModuleInfo* module_info);

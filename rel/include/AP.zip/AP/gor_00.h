#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGor00Patches(OSModuleInfo* module_info);

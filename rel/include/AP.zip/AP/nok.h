#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyNokPatches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyHeiPatches(OSModuleInfo* module_info);

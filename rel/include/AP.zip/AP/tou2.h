#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyTou2Patches(OSModuleInfo* module_info);

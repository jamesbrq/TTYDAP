#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyHomPatches(OSModuleInfo* module_info);

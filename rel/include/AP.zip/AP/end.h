#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyEndPatches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGor02Patches(OSModuleInfo* module_info);

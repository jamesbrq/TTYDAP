#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyWinPatches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyEkiPatches(OSModuleInfo* module_info);

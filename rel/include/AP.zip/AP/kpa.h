#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyKpaPatches(OSModuleInfo* module_info);

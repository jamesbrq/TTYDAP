#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGor03Patches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyPikPatches(OSModuleInfo* module_info);

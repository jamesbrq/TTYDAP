#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGor04Patches(OSModuleInfo* module_info);

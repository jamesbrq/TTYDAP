#pragma once

void ApplyAaaPatches();

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGraPatches(OSModuleInfo* module_info);

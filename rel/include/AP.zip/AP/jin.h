#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyJinPatches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyGorMiscPatches(OSModuleInfo* module_info);

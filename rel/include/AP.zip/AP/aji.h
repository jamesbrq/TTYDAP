#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyAjiPatches(OSModuleInfo* module_info);

#pragma once

#include <gc/OSLink.h>

using namespace gc::OSLink;

void ApplyLasPatches(OSModuleInfo* module_info);
